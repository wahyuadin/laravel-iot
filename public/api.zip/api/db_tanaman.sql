-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 07, 2024 at 07:46 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_tanaman`
--

-- --------------------------------------------------------

--
-- Table structure for table `gambar`
--

CREATE TABLE `gambar` (
  `id` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `profile` varchar(255) NOT NULL DEFAULT 'uploads/profile.jpg',
  `sampul` varchar(255) NOT NULL DEFAULT 'uploads/sampul.jpg'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `gambar`
--

INSERT INTO `gambar` (`id`, `id_user`, `profile`, `sampul`) VALUES
(3, 3, 'uploads/profile.jpg', 'uploads/sampul.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `monitor`
--

CREATE TABLE `monitor` (
  `id` int(11) NOT NULL,
  `kelembapan` varchar(255) DEFAULT NULL,
  `humadity` varchar(255) DEFAULT NULL,
  `temperatur` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `value` varchar(100) DEFAULT NULL,
  `waktu` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp() COMMENT ' '
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `monitor`
--

INSERT INTO `monitor` (`id`, `kelembapan`, `humadity`, `temperatur`, `status`, `value`, `waktu`) VALUES
(1, '70', '30', '25', 'normal', '', '2024-02-17 23:27:14'),
(2, 'required', 'required', 'required', 'required', '', '2024-02-18 07:03:46'),
(3, 'required', 'required', 'required', 'required', '', '2024-02-18 07:04:46'),
(4, 'required', 'required', 'required', 'required', '', '2024-02-18 07:04:51'),
(5, 'required', 'required', 'required', '$37', '', '2024-02-18 07:05:32'),
(6, 'required', 'required', 'required', '$37', '', '2024-02-18 07:05:55'),
(7, 'testing', 'testing', 'testing', 'testing', 'testing', '2024-02-19 06:55:03'),
(8, 'testing', 'testing', 'testing', 'testing', 'testing', '2024-02-19 06:55:15'),
(9, '99', '99', '99', 'ee', 'ee', '2024-02-19 09:25:51'),
(10, '63', '65', '99', 'ok', 'required', '2024-02-20 12:02:14'),
(11, '10', '25', '66', 'ok', 'required', '2024-02-20 12:05:37'),
(12, '10', '25', '66', 'ok', 'required', '2024-02-20 12:05:43'),
(13, '10', '24', '66', 'ok', 'required', '2024-02-20 12:05:48'),
(14, '10', '24', '66', 'ok again', 'required', '2024-02-20 12:06:42'),
(15, '10', '24', '66', 'ok again again', 'required', '2024-02-20 12:22:11'),
(16, '12', '12', '12', 'agains', 'required', '2024-02-20 12:34:56'),
(17, '12', '12', '12', 'agains', 's', '2024-02-20 12:35:04'),
(18, '12', '12', '12', 'agains', '123', '2024-02-20 12:35:14'),
(19, '-0.10%', '28.60%', '28.60°C', 'kekeringan', 'required', '2024-02-20 12:37:00'),
(20, '-0.10%', '28.60%', '28.60°C', 'kekeringan', 'required', '2024-02-20 12:37:31'),
(21, '-0.10%', '28.70%', '28.70°C', 'kekeringan', 'required', '2024-02-20 14:33:49'),
(22, '42.91%', '27.20%', '27.20°C', 'basah', '1', '2024-02-23 14:54:12'),
(23, '42.91%', '27.20%', '27.20°C', 'basah', '1', '2024-02-29 13:08:56'),
(24, '-0.10%', '27.40%', '27.40°C', 'kekeringan', '0.00', '2024-02-29 13:21:37'),
(25, '-0.10%', '27.40%', '27.40°C', 'kekeringan', '0.00', '2024-02-29 13:21:51'),
(26, '-0.10%', '27.50%', '27.50°C', 'kekeringan', '0.00', '2024-02-29 13:22:05'),
(27, '-0.10%', '27.40%', '27.40°C', 'kekeringan', '0.00', '2024-02-29 13:22:19'),
(28, '-0.10%', '27.50%', '27.50°C', 'kekeringan', '0.00', '2024-02-29 13:22:33'),
(29, '-0.10%', '27.40%', '27.40°C', 'kekeringan', '0.00', '2024-02-29 13:22:47'),
(30, '-0.10%', '27.40%', '27.40°C', 'kekeringan', '0.00', '2024-02-29 13:23:03'),
(31, '-0.10%', '27.50%', '27.50°C', 'kekeringan', '0.00', '2024-02-29 13:23:17'),
(32, '-0.10%', '27.50%', '27.50°C', 'kekeringan', '0.00', '2024-02-29 13:23:33'),
(33, '-0.10%', '27.50%', '27.50°C', 'kekeringan', '0.00', '2024-02-29 13:23:47'),
(34, '-0.10%', '27.40%', '27.40°C', 'kekeringan', '0.00', '2024-02-29 13:24:01'),
(35, '-0.10%', '27.50%', '27.50°C', 'kekeringan', '0.00', '2024-02-29 13:24:15'),
(36, '42.91%', '27.20%', '27.20°C', 'basah', '0.00', '2024-02-29 13:24:17'),
(37, '-0.10%', '27.40%', '27.40°C', 'kekeringan', '0.00', '2024-02-29 13:24:30'),
(38, '-0.10%', '27.40%', '27.40°C', 'kekeringan', '0.00', '2024-02-29 13:24:44'),
(39, '-0.10%', '27.40%', '27.40°C', 'kekeringan', '0.00', '2024-02-29 13:24:59'),
(40, '-0.10%', '27.40%', '27.40°C', 'kekeringan', '0.00', '2024-02-29 13:25:15'),
(41, '-0.10%', '27.40%', '27.40°C', 'kekeringan', '0.00', '2024-02-29 13:25:30'),
(42, '-0.10%', '27.50%', '27.50°C', 'kekeringan', '0.00', '2024-02-29 13:25:46'),
(43, '-0.10%', '27.50%', '27.50°C', 'kekeringan', '0.00', '2024-02-29 13:26:01'),
(44, '-0.10%', '27.40%', '27.40°C', 'kekeringan', '0.00', '2024-02-29 13:26:15'),
(45, '-0.10%', '27.40%', '27.40°C', 'kekeringan', '0.00', '2024-02-29 13:26:29'),
(46, '-0.10%', '27.50%', '27.50°C', 'kekeringan', '0.00', '2024-02-29 13:26:47'),
(47, '-0.10%', '27.50%', '27.50°C', 'kekeringan', '0.00', '2024-02-29 13:27:37'),
(48, '-0.10%', '27.50%', '27.50°C', 'kekeringan', '0.00', '2024-02-29 13:28:18'),
(49, '10.56%', '27.40%', '27.40°C', 'normal', '0.06', '2024-02-29 13:28:51'),
(50, '5.96%', '27.40%', '27.40°C', 'kering', '1.00', '2024-02-29 13:29:05'),
(51, '-0.10%', '27.40%', '27.40°C', 'kekeringan', '0.00', '2024-02-29 13:29:19'),
(52, '9.68%', '27.40%', '27.40°C', 'kering', '1.00', '2024-02-29 13:29:34'),
(53, '-0.10%', '27.50%', '27.50°C', 'kekeringan', '0.00', '2024-02-29 13:30:56'),
(54, '1.17%', '27.40%', '27.40°C', 'kering', '1.00', '2024-02-29 13:31:13'),
(55, '7.62%', '27.50%', '27.50°C', 'kering', '1.00', '2024-02-29 13:31:28'),
(56, '12.51%', '27.40%', '27.40°C', 'normal', '0.25', '2024-02-29 13:40:16'),
(57, '-0.10%', '27.40%', '27.40°C', 'kekeringan', '0.00', '2024-02-29 13:40:20'),
(58, '-0.10%', '27.40%', '27.40°C', 'kekeringan', '0.00', '2024-02-29 13:41:51'),
(59, '-0.10%', '27.40%', '27.40°C', 'kekeringan', '0.00', '2024-02-29 13:44:12'),
(60, '-0.10%', '27.30%', '27.30°C', 'kekeringan', 'required', '2024-02-29 13:44:57'),
(61, '-0.10%', '27.40%', '27.40°C', 'kekeringan', 'required', '2024-02-29 13:47:32'),
(62, '-0.10%', '27.40%', '27.40°C', 'kekeringan', 'required', '2024-02-29 13:47:42'),
(63, '-0.10%', '27.30%', '27.30°C', 'kekeringan', '0.00', '2024-02-29 13:48:32'),
(64, '-0.10%', '27.30%', '27.30°C', 'kekeringan', '0.00', '2024-02-29 13:52:26'),
(65, '-0.10%', '27.30%', '27.30°C', 'kekeringan', '0.00', '2024-02-29 13:52:51'),
(66, '-0.10%', '27.20%', '27.20°C', 'kekeringan', '0.00', '2024-02-29 13:53:35');

-- --------------------------------------------------------

--
-- Table structure for table `token`
--

CREATE TABLE `token` (
  `id` int(11) NOT NULL,
  `id_device` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `token`
--

INSERT INTO `token` (`id`, `id_device`, `token`) VALUES
(1, 'node_mcu', 'tanaman');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `nama`, `username`, `password`) VALUES
(3, 'wahyuadin', 'wahyu', '$2y$10$8wJ/FprlGtLhsNQNfWbc1uvOqCKmVozLI79smZYe6ophXAqbCvtxO');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `gambar`
--
ALTER TABLE `gambar`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id_token` (`id_user`);

--
-- Indexes for table `monitor`
--
ALTER TABLE `monitor`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `token`
--
ALTER TABLE `token`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `gambar`
--
ALTER TABLE `gambar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `monitor`
--
ALTER TABLE `monitor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- AUTO_INCREMENT for table `token`
--
ALTER TABLE `token`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `gambar`
--
ALTER TABLE `gambar`
  ADD CONSTRAINT `gambar_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
